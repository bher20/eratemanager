<script lang="ts">
  import "../app.css";
</script>

<slot />
