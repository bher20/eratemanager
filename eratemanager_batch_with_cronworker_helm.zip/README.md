# eRateManager skeleton with refresh handler wired in
